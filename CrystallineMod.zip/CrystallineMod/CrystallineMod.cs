using Terraria.ModLoader;

namespace CrystallineMod
{
	public class CrystallineMod : Mod
	{
		public CrystallineMod()
		{
		}
	}
}